 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: D:\Export_Storage\ExportBase\0\239415\Output\KiCAD\KiCAD\symbols.lib
 
 
After you have used Ultra Librarian to export library:
**************************************************
**To import your new library symbols into KiCad:**
**************************************************
1. Open KiCad.
2. On the program/tool list, go to Eeschema.
3. Select *Preferences* from the menu bar then select *Library*.
4. Click *Add* and choose the newly exported *.LIB* file.
5. You have now successfully imported your new symbol library!

**************************************************************
**To import your new library footprints/patterns into KiCad:**
**************************************************************
1. Open KiCad.
2. On the program/tool list, go to Pcbnew.
3. Follow the same steps as you would importing symbols, only this time select the *.kicad_mod* file.
4. You have now successfully imported your new footprint/pattern.


**************************************************************
**    !!!!!!!!!!!!!        WARNING        !!!!!!!!!!!!!     **
**************************************************************
KiCAD does not support filled/hatched polygons on footprints!
All polygons will be represented with an outline made of lines in each design.
Etch polygons will be drawn on the documentation layer, "Dwgs.User", and can be filled during board creation.
 
 
